# RDR2 PS5 Controller Trainer

A minimal **Python / pygame** trainer that helps you master every default **Red Dead Redemption 2** control on a PS5 (DualSense) controller.

## Features
- Randomised timed prompts covering all default actions (on‑foot, horse, combat, Dead Eye, more).
- Simple scoring (+1 correct / 0 incorrect) and end‑session summary.
- Filter by category or run **All‑in‑One** mode.
- Lightweight: pure text prompts—no external assets required.

## Quick Start
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python -m src.trainer
```

## Roadmap
- Sound / haptic feedback
- Configurable difficulty & timeouts
- High‑score persistence
- Gamepad overlay graphics

## Contributing
PRs and issues are welcome—please open one!

## License
MIT © 2025 YourName
