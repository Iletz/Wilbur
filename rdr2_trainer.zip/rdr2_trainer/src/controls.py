"""Default Red Dead Redemption 2 controls for PS5 (DualSense) controller."""

CONTROLS = {
    # On‑foot actions
    "Take cover": "R1",
    "Jump / Climb": "Square",
    "Interact / Talk": "Triangle",
    "Sprint": "X",
    "Aim (Combat)": "L2",
    "Shoot (Combat)": "R2",
    "Reload": "Circle",
    "Dead Eye": "R3",
    # Horse actions
    "Accelerate (Horse)": "X",
    "Brake / Reverse (Horse)": "R1",
    "Gallop (Horse)": "Square",
    "Aim (Horseback Combat)": "L2",
    "Shoot (Horseback Combat)": "R2",
    # Misc
    "Open Weapon Wheel": "L1",
    "Open Item Wheel": "R1 (hold)",
    "Pause Menu": "Options",
    "Map": "Touchpad",
}

CATEGORIES = {
    "OnFoot": [
        "Take cover", "Jump / Climb", "Interact / Talk", "Sprint",
        "Aim (Combat)", "Shoot (Combat)", "Reload", "Dead Eye"
    ],
    "Horse": [
        "Accelerate (Horse)", "Brake / Reverse (Horse)", "Gallop (Horse)",
        "Aim (Horseback Combat)", "Shoot (Horseback Combat)"
    ],
    "Misc": [
        "Open Weapon Wheel", "Open Item Wheel", "Pause Menu", "Map"
    ],
}
