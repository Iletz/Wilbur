"""Minimal RDR2 controller trainer using pygame."""
import random, time, sys
import pygame
from .controls import CONTROLS, CATEGORIES

WIDTH, HEIGHT = 640, 480
FPS = 60
PROMPT_TIME = 3.0  # seconds to respond

def main():
    pygame.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("RDR2 PS5 Controller Trainer")
    clock = pygame.time.Clock()

    category = "All"
    actions = list(CONTROLS.keys())
    score = 0
    total = 0

    font = pygame.font.SysFont(None, 32)
    prompt = random.choice(actions)
    prompt_start = time.time()

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                # Press any key to reveal answer and go next
                total += 1
                # Simplistic scoring: space = correct, else incorrect (placeholder)
                if event.key == pygame.K_SPACE:
                    score += 1
                prompt = random.choice(actions)
                prompt_start = time.time()

        # Timeout handling
        if time.time() - prompt_start > PROMPT_TIME:
            total += 1
            prompt = random.choice(actions)
            prompt_start = time.time()

        screen.fill((30, 30, 30))
        # Render prompt
        txt = font.render(f"What button for: {prompt}?", True, (220, 220, 220))
        screen.blit(txt, (20, 200))

        # Render score
        scr = font.render(f"Score: {score}/{total}", True, (180, 180, 180))
        screen.blit(scr, (20, 20))

        pygame.display.flip()
        clock.tick(FPS)

    pygame.quit()
    print(f"Final score: {score}/{total}")
    sys.exit()

if __name__ == "__main__":
    main()
