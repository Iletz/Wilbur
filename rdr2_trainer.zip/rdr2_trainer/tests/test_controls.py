from src.controls import CONTROLS

def test_unique_buttons():
    assert len(set(CONTROLS.values())) >= 10
